package jp.jaxa.iss.kibo.rpc.sampleapk.FSM_STATE;


public enum FSM_STATE {
    Init,
    Navigate,
    Capture_Image,
    Detect_Object,
    Report_Object,
    Go_To_Lost_Item,
    Astronaut,
    Finish,
    Mission_Complete,
}