package jp.jaxa.iss.kibo.rpc.sampleapk.ImagePreprocessor;

import org.opencv.core.Mat;

public class Arucoref {
    public Mat image;
    public Integer id = 999;
    public Arucoref(){
    }
}
