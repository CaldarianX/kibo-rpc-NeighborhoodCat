package jp.jaxa.iss.kibo.rpc.sampleapk.Nagivate;

import gov.nasa.arc.astrobee.types.Point;
import gov.nasa.arc.astrobee.types.Quaternion;

public class NavigatePointData{
    public Quaternion quaternion;
    public Point point;

    public NavigatePointData(Quaternion quaternion,Point point){
        this.quaternion = quaternion;
        this.point = point;
    }
}