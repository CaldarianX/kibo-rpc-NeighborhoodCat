package jp.jaxa.iss.kibo.rpc.sampleapk.Camera;

public enum Camera_Type {
    NavCam,
    DockCam,
}